# Cambios de secciones del External

- Se añadieron las pestañas AIMBOT y TEXTURAS al menú neón.
- AIMBOT organiza los controles existentes en este orden: PECHO AVATAR, HEAD AVATAR, CUELLO AVATAR y SINTURA AVATAR.
- TEXTURAS muestra el encabezado HOLOGRAMA ARMA y el control HOLOGRAMA AZUL AVATAR.
- El interruptor de HOLOGRAMA AZUL AVATAR es únicamente visual/local en esta versión. El archivo Holograma Vip Jere Store.3105 no contiene un proyecto editable integrado al catálogo, por lo que no se presenta como un parche funcional ni se aplica a otra app.
- Los controles de avatar conservan la operación de paquetes .3105 ya existente en el proyecto.
- No se ha compilado ni probado la IPA en Xcode/iPhone.
