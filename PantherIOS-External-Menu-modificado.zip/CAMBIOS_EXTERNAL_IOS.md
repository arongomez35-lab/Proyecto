# Cambios External iOS

- Se eliminó la pantalla de calculadora y su código de desbloqueo 052009.
- La pantalla de acceso ahora usa el diseño oscuro EXTERNAL - iOS, con campo Mostrar/Ocultar y botón Entrar.
- La key local de demostración `Aron` abre el menú sin requerir conexión con Lovable. Las demás keys siguen validándose en el servidor configurado.
- El menú muestra los cuatro paquetes que documenta el proyecto: Head Avatar, Cuello Avatar, Pecho Avatar y Sintura Avatar.
- Los interruptores conservan la operación original del proyecto: aplicar el paquete .3105 o restaurar el cambio registrado. No son funciones de aimbot.

Nota: `Aron` es una clave fija de demostración incluida en el código; no debe usarse como licencia de producción.
